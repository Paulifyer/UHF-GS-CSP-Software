#ifndef RLOG_H_
#define RLOG_H_

#include <conf_log.h>

#if ENABLE_LOG_SERVER
#include <../src/server/rlog_server.h>
#endif

#endif /* RLOG_H_ */
